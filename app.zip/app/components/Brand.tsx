import React from 'react';



const Brand: React.FC = () => {
  return (
    
      <div>NA</div>
    
  );
};

export default Brand;
